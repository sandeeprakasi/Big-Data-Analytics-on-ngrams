echo "batch_view1 creation basing on the year attribute for match_count"


hive -e 'SELECT ngram,MAX(match_count) AS max_count,MIN(match_count) AS min_count FROM ngrams WHERE year BETWEEN '1520' AND '1700' group by ngram' > /home/rakas1s/project/batch_views/batch_view1.csv




echo " processing the batch_view to give it to the serving layer"
echo "repacing tab seperator with comma"

cat project/batch_views/batch_view1.csv | sed -e 's/\t/,/g' > project/batch_views/batchview_a.csv

echo "removing quotes if any present and replacing ,, with ,"

cat project/batch_views/batchview_a.csv | sed -e 's/"//g' | sed -e 's/,,/,/g' > project/batch_views/batchview_b.csv

echo "deleting batchview+_a.csv"

rm -f project/batch_views/batchview_a.csv

echo "checking the files whether the fields are comma(,) seperated"

cat project/batch_views/batchview_b.csv | awk -F ',' '{printf(%s,%i,%i);\n,$1,$2,$3}'\ > project/batch_views/batchview_c.csv

echo "removing the piped unwanted files to avoid confusion"

rm -f project/batch_views/batchview_b.csv

echo "replacing the original batch_view1  with the processed data"

mv project/batch_views/batchview_c.csv project/batch_views/batch_view1.csv

echo "renaming batch_view1.csv to batch_view1.sql"

mv project/batch_views/batch_view1.csv project/batch_views/batch_view1.sql



########################################################################################################






echo "batch_view2 creation basing on the year attribute on volume_count"


hive -e 'SELECT ngram,MAX(volume_count) AS max_volume,MIN(volume_count) AS min_volume FROM ngrams WHERE year BETWEEN '1520' AND '1700' group by ngram' > /home/rakas1s/project/batch_views/batch_view2.csv



echo "processing the batch_view to give it to the serving layer"
echo "repacing tab seperator with comma"

cat project/batch_views/batch_view2.csv | sed -e 's/\t/,/g' > project/batch_views/batchview_a.csv
echo "removing quotes if any present and replacing ,, with ,"

cat project/batch_views/batchview_a.csv | sed -e 's/"//g' | sed -e 's/,,/,/g' > project/batch_views/batchview_b.csv

echo "deleting the old files"

rm -f project/batch_views/batchview_a.csv

echo "checking the files whether the fields are comma(,) seperated"

cat project/batch_views/batchview_b.csv | awk -F ',' '{printf(%s,%i,%i\n,$1,$2,$3)}'\ > project/batch_views/batchview_c.csv

echo "removing the piped unwanted files to avoid confusion"

rm -f project/batch_views/batchview_b.csv

echo "replacing the original batch_view2  with the processed data"

mv project/batch_views/batchview_c.csv project/batch_views/batch_view2.csv

echo "renaming the file"

mv project/batch_views/batch_view2.csv project/batch_views/batch_view2.sql
