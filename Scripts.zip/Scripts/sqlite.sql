
# creating an sqlite table and giving the batch view as an input to it

DROP TABLE IF EXISTS batch_view1;

CREATE TABLE batch_view1(ngram1 STRING,max_match INT,min_match  mv INT);
.separator ","
.import  project/batch_views/batch_view1.sql batch_view1



# creating an sqlite table and giving the batch view as an input to it



DROP TABLE IF EXISTS batch_view2;

CREATE TABLE batch_view2(ngram STRING,max_volume INT,min_volume INT);

.separator ","

.import project/batch_views/batch_view2.sql batch_view2


