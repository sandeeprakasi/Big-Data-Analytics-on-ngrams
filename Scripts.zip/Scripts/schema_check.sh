#Description: This script with do schema validation for each column of "ngrams.csv" file and will parse through only matchedcolumns into final file.Script first starts with checking the existence of the orginal source file and will only proceed if file is present.
#Global-Id: rakas1s
#Creation Date: 04/24/2016
#Version :1.1

echo "Info: Initiating Script....."
sleep 2

date1=`date +%m-%d-%y`
time1=`date +%T`
file_name=ngrams.csv

echo "Info: Script Started on $date1 at $time1"

src_path=/home/rakas1s/project/data/raw/
hdfs_path=/user/rakas1s/project/data/raw

echo "Info: Changing Directory to $src_path"
sleep 2

echo "Info: Checking if $file_name is present under path $src_path"
sleep 2

if [ ! -f $file_name ]
        then
                echo "Error: File $file_name doesn't exist under path $src_path. Exiting Script."
                exit 1
        else
                echo "Info: $file_name File Exists!"
fi

echo "Info: Initiating Schema Check"
sleep 2
awk -F"\t" '$1>"  " {print $0}' $file_name > ngrams1.csv
echo "Info: Column1 Parsed Successfully"

awk -F"\t" '$2>"  " {print $0}' ngrams1.csv | awk -F"\t" '$2~ "^[0-9][0-9]*$" { print $0 }' > ngrams2.csv
echo "Info: Column2 Parsed Successfully"
echo "Info: Removing ngrams1.csv"
rm -f ngrams1.csv
echo "Info: ngrams1.csv Removed Successfully"

awk -F"\t" '$3>"  " {print $0}' ngrams2.csv | awk -F"\t" '$3~ "^[0-9][0-9]*$" { print $0 }' > ngrams3.csv
echo "Info: Column3 Parsed Successfully"
echo "Info: Removing ngrams2.csv"
rm -f ngrams2.csv
echo "Info: ngrams2.csv Removed Successfully"

awk -F"\t" '$4>"  " {print $0}' ngrams3.csv | awk -F"\t" '$4~ "^[0-9][0-9]*$" { print $0 }' > ngrams4.csv
echo "Info: Column4 Parsed Successfully"
echo "Info: Removing ngrams3.csv"
rm -f ngrams3.csv
echo "Info: ngrams3.csv Removed Successfully"

awk -F"\t" '$5>"  " {print $0}' ngrams4.csv | awk -F"\t" '$5~ "^[0-9][0-9]*$" { print $0 }' > ngrams5.csv
echo "Info: Column5 Parsed Successfully"
echo "Info: Removing ngrams4.csv"
rm -f ngrams4.csv
echo "Info: ngrams4.csv Removed Successfully"

sleep 2
echo "Info: Schema Check Completed Successfully"

echo "Info: Renaming ngrams5.csv to $file_name"
echo "Warning: Old file will be overwritten"
mv ngrams5.csv $file_name
sleep 2
echo "Info: Moving Files on HDFS"

hadoop fs -copyFromLocal -f $src_path$filename $hdfs_path
echo "Info: $file_name Moved Successfully on HDFS path $hdfs_path" 

echo "Info: Exiting Script"
